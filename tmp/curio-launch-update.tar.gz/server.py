#!/usr/bin/env python3
"""
Curio（知所）— 统一画布后端
任意输入 → 内容提取 → 图谱持久化 → LLM 对话代理
"""

import os
import re
import json
import time
import uuid
import asyncio
import sqlite3
import hashlib
import math
import random
from datetime import datetime, date, timedelta
from pathlib import Path
from typing import Optional
from urllib.parse import quote

from env_loader import load_env_files, env_key

load_env_files()

import httpx
from fastapi import FastAPI, HTTPException, Query, UploadFile, File, Form, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from fastapi.responses import StreamingResponse, FileResponse, HTMLResponse
from pydantic import BaseModel

from extract import extract, detect_platform, normalize_input_url, PLATFORM_NAMES, CACHE_DIR
from auth import (
    init_auth_tables,
    send_login_code,
    verify_login_code,
    login_with_password,
    get_user_by_token,
    logout_token,
    is_admin_user,
)
from quota import check_graph_create, check_chat, get_quota_status
from structure import (
    build_structure_prompt,
    parse_structure_json,
    compile_graph_state,
    fallback_structure,
    normalize_video_url,
)
from search_providers import search_image as fetch_image, search_web
from curio_agent import run_curio_agent

_START_TIME = time.time()
ROOT = Path(__file__).parent
DATA_DIR = ROOT / "data"
UPLOAD_DIR = ROOT / "uploads"
DATA_DIR.mkdir(exist_ok=True)
UPLOAD_DIR.mkdir(exist_ok=True)

DEEPSEEK_BASE = env_key("DEEPSEEK_BASE") or "https://api.deepseek.com/v1"
DEEPSEEK_KEY = env_key("DEEPSEEK_API_KEY")
DEEPSEEK_MODEL = env_key("DEEPSEEK_MODEL") or "deepseek-chat"
SONIOX_KEY = env_key("SONIOX_API_KEY")
PORT = int(os.environ.get("CANVAS_PORT", "8777"))
CURIO_BASE_PATH = (env_key("CURIO_BASE_PATH") or "").rstrip("/")

app = FastAPI(title="Curio")
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"])

# ─── Task queue (content extraction) ─────────────────
task_events: dict[str, asyncio.Queue] = {}
task_results: dict[str, dict] = {}
task_status: dict[str, str] = {}


def create_task() -> str:
    tid = uuid.uuid4().hex[:8]
    task_events[tid] = asyncio.Queue()
    task_status[tid] = "running"
    return tid


async def emit_event(tid: str, event: dict):
    if tid in task_events:
        await task_events[tid].put(event)


# ─── SQLite ──────────────────────────────────────────
DB_PATH = DATA_DIR / "graphs.db"


def init_db():
    with sqlite3.connect(DB_PATH) as db:
        db.execute("""CREATE TABLE IF NOT EXISTS graphs (
            id TEXT PRIMARY KEY,
            title TEXT,
            source_type TEXT,
            source_ref TEXT,
            source_content TEXT,
            state_json TEXT,
            created_at TEXT,
            updated_at TEXT
        )""")
        cols = {r[1] for r in db.execute("PRAGMA table_info(graphs)").fetchall()}
        if "user_id" not in cols:
            db.execute("ALTER TABLE graphs ADD COLUMN user_id TEXT")
        if "visibility" not in cols:
            db.execute("ALTER TABLE graphs ADD COLUMN visibility TEXT DEFAULT 'private'")
        db.execute("""CREATE TABLE IF NOT EXISTS usage_logs (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id TEXT,
            action TEXT NOT NULL,
            graph_id TEXT,
            meta_json TEXT,
            created_at TEXT NOT NULL
        )""")
        db.execute("""CREATE TABLE IF NOT EXISTS invites (
            code TEXT PRIMARY KEY,
            email TEXT,
            max_uses INTEGER DEFAULT 1,
            uses INTEGER DEFAULT 0,
            expires_at TEXT,
            created_at TEXT NOT NULL
        )""")
        db.execute("""CREATE TABLE IF NOT EXISTS entitlements (
            user_id TEXT PRIMARY KEY,
            tier TEXT NOT NULL DEFAULT 'free',
            expires_at TEXT,
            source TEXT,
            note TEXT,
            operator TEXT,
            updated_at TEXT NOT NULL
        )""")
        db.execute("""CREATE TABLE IF NOT EXISTS quota_grants (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id TEXT NOT NULL,
            kind TEXT NOT NULL,
            amount INTEGER NOT NULL,
            source TEXT,
            note TEXT,
            operator TEXT,
            created_at TEXT NOT NULL
        )""")
        db.execute("CREATE INDEX IF NOT EXISTS idx_graphs_user ON graphs(user_id)")
        db.execute("CREATE INDEX IF NOT EXISTS idx_usage_user ON usage_logs(user_id, created_at)")
        db.execute("CREATE INDEX IF NOT EXISTS idx_quota_grants_user ON quota_grants(user_id, created_at)")
        init_auth_tables(db)


init_db()


def log_usage(action: str, user_id: str | None = None, graph_id: str | None = None, meta: dict | None = None):
    """SaaS 用量埋点：ingest / chat / extract 等，公测前用于配额与计费。"""
    try:
        with sqlite3.connect(DB_PATH) as db:
            db.execute(
                "INSERT INTO usage_logs (user_id, action, graph_id, meta_json, created_at) VALUES (?,?,?,?,?)",
                [user_id or "__local__", action, graph_id, json.dumps(meta or {}, ensure_ascii=False), now_iso()],
            )
    except Exception:
        pass


def _bearer_token(request: Request | None) -> str | None:
    if not request:
        return None
    auth = (request.headers.get("Authorization") or "").strip()
    if auth.lower().startswith("bearer "):
        return auth[7:].strip() or None
    return None


def request_user(request: Request | None) -> dict | None:
    if not request:
        return None
    user = get_user_by_token(_bearer_token(request))
    if user:
        return user
    legacy = (request.headers.get("X-Curio-User") or "").strip()
    if legacy:
        return {"id": legacy, "email": "", "is_admin": False}
    return None


def request_user_id(request: Request | None) -> str | None:
    u = request_user(request)
    return u["id"] if u else None


def public_beta_mode() -> bool:
    return env_key("QUOTA_ENFORCE") == "1"


def require_logged_in(request: Request | None):
    if not public_beta_mode():
        return
    if not request_user(request):
        raise HTTPException(401, "请先登录后再开始探索")


def quota_enforced(user_id: str | None, request: Request | None = None) -> bool:
    if not public_beta_mode():
        return False
    u = request_user(request)
    if not u:
        return False
    if u.get("is_admin"):
        return False
    return True


def now_iso() -> str:
    return datetime.now().isoformat()


def estimate_source_duration_sec(source: dict | None) -> int:
    """Best-effort duration for video/STT credit accounting."""
    source = source or {}
    for key in ("duration_sec", "duration", "audio_duration_sec"):
        try:
            v = float(source.get(key) or 0)
            if v > 0:
                return int(v)
        except Exception:
            pass
    segments = source.get("segments") or []
    if isinstance(segments, list) and segments:
        starts: list[float] = []
        for seg in segments[-10:]:
            if not isinstance(seg, dict):
                continue
            try:
                starts.append(float(seg.get("start_sec") or seg.get("start") or 0))
            except Exception:
                pass
        if starts:
            return int(max(starts) + 60)
    return 0


def usage_meta_for_source(source: dict | None, extra: dict | None = None) -> dict:
    source = source or {}
    platform = source.get("platform") or source.get("type") or ""
    is_video = bool(source.get("video_url")) or platform in ("bilibili", "youtube", "wechat_video")
    meta = {"platform": platform, "is_video": is_video}
    dur = estimate_source_duration_sec(source)
    if dur:
        meta["duration_sec"] = dur
    if extra:
        meta.update(extra)
    return meta


def slug_id(text: str) -> str:
    s = re.sub(r"[^\w\u4e00-\u9fff]+", "_", text.lower().strip())[:40]
    return s.strip("_") or uuid.uuid4().hex[:8]


def nest_slug_fn(parent_id: str):
    """Entity ids nested under the node being questioned."""

    def fn(raw: str) -> str:
        slug = slug_id(raw)
        if not parent_id or not slug:
            return slug
        prefix = f"{parent_id}__"
        nid = f"{prefix}{slug}"[:52]
        return nid

    return fn


# ─── LLM helper ──────────────────────────────────────
async def llm_chat(messages: list, temperature: float = 0.7, max_tokens: int = 2048) -> str:
    if not DEEPSEEK_KEY:
        raise HTTPException(503, "DEEPSEEK_API_KEY 未配置")
    async with httpx.AsyncClient(timeout=90) as cl:
        r = await cl.post(
            f"{DEEPSEEK_BASE}/chat/completions",
            headers={"Authorization": f"Bearer {DEEPSEEK_KEY}", "Content-Type": "application/json"},
            json={"model": DEEPSEEK_MODEL, "messages": messages, "temperature": temperature, "max_tokens": max_tokens},
        )
    if r.status_code != 200:
        raise HTTPException(502, f"LLM error {r.status_code}: {r.text[:300]}")
    return r.json()["choices"][0]["message"]["content"]


def make_root_node(source: dict) -> tuple[str, dict]:
    """Build root node id + def from extracted/summarized source."""
    title = source.get("title") or source.get("keyword") or "探索起点"
    nid = slug_id(title)
    base = nid
    i = 1
    while len(nid) < 3:
        nid = f"node_{uuid.uuid4().hex[:6]}"
    platform = source.get("platform", "")
    icons = {
        "youtube": "▶️", "bilibili": "📺", "wechat": "💚", "wechat_video": "🎬",
        "xiaohongshu": "📕", "twitter": "🐦", "generic": "🌐", "text": "💡", "image": "🖼️", "keyword": "✨",
    }
    icon = icons.get(platform, icons.get(source.get("type", ""), "📌"))
    summary = (source.get("summary") or source.get("content") or "")[:500]
    return nid, {
        "id": nid,
        "size": 95,
        "icon": icon,
        "gradient": ["#60a5fa", "#a78bfa", "#f472b6"],
        "label": title[:20].replace(" ", "\n") if len(title) > 12 else title,
        "title": title,
        "sub": source.get("pname") or source.get("type", "输入") + " · 探索起点",
        "text": summary,
        "source": source,
    }


def default_canvas_state(root_id: str, root_def: dict, source: dict) -> dict:
    cx, cy = 2000, 1400
    return {
        "sessionId": None,
        "source": source,
        "nodes": [root_id],
        "connections": [],
        "positions": {root_id: {"x": cx, "y": cy}},
        "nodeOrder": [root_id],
        "nodeDefs": {root_id: root_def},
        "chats": {},
    }


VIDEO_UNRELIABLE_MARKERS = (
    "⚠️ 视频转录失败",
    "⚠️ 视频下载失败",
    "语音识别结果为空",
    "视频下载失败或文件损坏",
    "视频号解析服务不可用",
    "解析服务不可用",
    "⚠️ 无法解析视频地址",
    "⚠️ 视频号",
    "未能转录",
)


def _friendly_video_block(tail: str, fallback: str) -> str:
    t = (tail or "").strip()
    if not t or "No such file or directory" in t or "yt-dlp" in t.lower():
        return fallback
    return t[:200]


def video_source_unreliable(source: dict) -> str | None:
    """Block hallucinated concept maps when video transcript is missing."""
    platform = source.get("platform") or ""
    content = (source.get("content") or "").strip()
    fallback = "视频未能转录，无法生成可靠的概念图"
    primary = content.split("⚠️", 1)[0].strip()
    if "⚠️" in content and len(primary) >= 24:
        return None
    if content.startswith("⚠️"):
        tail = content.lstrip("⚠️ ").strip("：: \n")
        return _friendly_video_block(tail, "内容提取失败，无法生成可靠的概念图")
    for marker in VIDEO_UNRELIABLE_MARKERS:
        if marker in content:
            tail = content.split(marker, 1)[-1].strip("：: \n")
            return _friendly_video_block(tail, fallback)
    if platform not in ("bilibili", "youtube", "wechat_video"):
        return None
    segments = source.get("segments") or []
    if platform == "wechat_video":
        if "【语音转录】" not in content and not segments:
            if len(content) < 120:
                return (
                    "视频号未能获取语音或正文，暂时无法成图。"
                    "请稍后重试，或改用公众号链接 / 粘贴文字。"
                )
        return None
    if not segments and platform in ("bilibili", "youtube"):
        check = primary if "⚠️" in content else content
        if "【语音转录】" not in check and len(check.strip()) < 15:
            return (
                "未获取到视频语音内容，无法可靠成图。"
                "请确认链接可公开访问，或改用粘贴字幕/文章。"
            )
    return None


async def compile_source_to_state(source: dict, progress=None) -> tuple[dict, dict]:
    """Extract → LLM structure → multi-node radial graph."""
    meta = {"structure_degraded": False, "structure_reason": ""}
    unreliable = video_source_unreliable(source)
    if unreliable:
        raise ValueError(unreliable)
    if progress:
        await progress({"step": "structuring", "detail": "正在理解内容，生成概念图…"})
    vu = normalize_video_url(source.get("video_url") or "")
    if vu:
        source["video_url"] = vu
    try:
        if not DEEPSEEK_KEY:
            raise ValueError("DEEPSEEK_API_KEY 未配置")
        prompt = build_structure_prompt(source)
        raw = await llm_chat([{"role": "user", "content": prompt}], temperature=0.35, max_tokens=4096)
        struct = parse_structure_json(raw)
        if not (struct.get("concepts") or []):
            raise ValueError("概念图为空")
    except Exception as e:
        meta["structure_degraded"] = True
        meta["structure_reason"] = str(e)[:300]
        struct = fallback_structure(source)
    state = compile_graph_state(source, struct)
    if meta["structure_degraded"]:
        state.setdefault("meta", {})
        state["meta"]["structure_degraded"] = True
        state["meta"]["structure_reason"] = meta["structure_reason"]
    if vu:
        if progress:
            await progress({"step": "frames", "detail": "从视频截取节点配图…"})
        await enrich_state_video_frames(state)
    return state, meta


async def enrich_state_video_frames(state: dict) -> int:
    """Use ffmpeg to grab frames at each node's timestamp — no random web images."""
    from extract import extract_frame_at, resolve_local_video_path

    source = state.get("source") or {}
    node_defs = state.get("nodeDefs", {})
    nodes = state.get("nodes") or []
    root_id = nodes[0] if nodes else None
    root_def = node_defs.get(root_id, {}) if root_id else {}

    video_url = normalize_video_url(source.get("video_url") or root_def.get("video") or "")
    if not video_url:
        return 0

    video_path = resolve_local_video_path(video_url)
    if not video_path:
        return 0

    base = video_path.stem
    enriched = 0

    for nid in nodes:
        node = node_defs.get(nid)
        if not node:
            continue
        start_sec = float(node.get("start_sec") or 0)
        is_root = nid == root_id
        is_timeline = start_sec > 0
        sub = (node.get("sub") or "").lower()
        is_spawned = "追问" in sub or "hermes" in sub or "curio" in sub or "延展" in sub

        # 追问衍生的概念：不挂视频、不截帧
        if is_spawned and not is_root:
            node.pop("video", None)
            continue

        if not is_root and not is_timeline:
            node.pop("video", None)
            continue

        sec = start_sec if is_timeline else 1.0
        frame_id = f"{base}_n{int(sec * 10)}_{nid[:10]}"
        gallery: list[str] = []
        url = await extract_frame_at(str(video_path), sec, frame_id)
        if url:
            gallery.append(url)
        if is_timeline:
            url2 = await extract_frame_at(str(video_path), start_sec + 2.5, f"{frame_id}_b")
            if url2 and url2 not in gallery:
                gallery.append(url2)
        if gallery:
            node["hero"] = gallery[0]
            node["gallery"] = gallery
            enriched += 1
        if is_root or is_timeline:
            node["video"] = video_url

    state["nodeDefs"] = node_defs
    return enriched


def save_graph(
    graph_id: str,
    title: str,
    source_type: str,
    source_ref: str,
    source_content: str,
    state: dict,
    user_id: str | None = None,
):
    state["sessionId"] = graph_id
    ts = now_iso()
    with sqlite3.connect(DB_PATH) as db:
        exists = db.execute("SELECT id FROM graphs WHERE id=?", [graph_id]).fetchone()
        if exists:
            db.execute(
                "UPDATE graphs SET title=?, source_content=?, state_json=?, updated_at=? WHERE id=?",
                [title, source_content[:50000], json.dumps(state, ensure_ascii=False), ts, graph_id],
            )
        else:
            db.execute(
                """INSERT INTO graphs
                   (id, title, source_type, source_ref, source_content, state_json, created_at, updated_at, user_id, visibility)
                   VALUES (?,?,?,?,?,?,?,?,?,?)""",
                [
                    graph_id, title, source_type, source_ref,
                    source_content[:50000], json.dumps(state, ensure_ascii=False),
                    ts, ts, user_id, "private",
                ],
            )


# ─── Models ──────────────────────────────────────────
class ExtractRequest(BaseModel):
    url: str


class TextIngestRequest(BaseModel):
    text: str
    mode: str = "auto"  # auto | keyword | text


class ChatRequest(BaseModel):
    graph_id: str
    node_id: str
    question: str
    thread_history: list = []
    source_content: str = ""


class GraphSaveRequest(BaseModel):
    state: dict


class GraphMetaPatch(BaseModel):
    title: Optional[str] = None


class GraphImportRequest(BaseModel):
    state: dict
    title: Optional[str] = None


class GraphClaimRequest(BaseModel):
    ids: list[str] = []


class NodeImageRequest(BaseModel):
    graph_id: str
    node_id: str
    query: str = ""


class AgentSearchRequest(BaseModel):
    query: str
    graph_id: Optional[str] = None


class AuthSendCodeRequest(BaseModel):
    email: str


class AuthVerifyRequest(BaseModel):
    email: str
    code: str


class AuthLoginRequest(BaseModel):
    email: str
    password: str


class AdminGrantRequest(BaseModel):
    user_id: Optional[str] = None
    email: Optional[str] = None
    kind: str
    amount: int
    source: str = "admin"
    note: str = ""




# ─── Extraction tasks ────────────────────────────────
def user_friendly_ingest_error(exc: Exception, url: str = "") -> str:
    """Turn backend/infra errors into clear user messages (no raw URLs/stack)."""
    msg = str(exc) or "提取失败"
    low = msg.lower()
    url_low = (url or "").lower()
    if "视频号" in msg or "weixin.qq.com/sph" in url_low or "parse_sph" in low or "litao" in low:
        return (
            "视频号外部解析节点暂时无响应（不是你的链接问题）。"
            "请稍后重试，或先换公众号 / B站 / 小红书短链。"
        )
    if "twitter" in low or "x.com" in url_low or "x/twitter" in msg.lower():
        return (
            "X/Twitter 从当前服务器网络无法访问。"
            "请粘贴推文正文，或稍后重试。"
        )
    if "xiaohongshu" in low or "小红书" in msg:
        if "xsec" in low or "短链" in msg:
            return "小红书请使用 xhslink 短链，或从 App 重新复制完整分享链接。"
        return "小红书内容暂时无法解析，请换 xhslink 短链或粘贴笔记正文。"
    if "bilibili" in low and "语音" in msg:
        return msg  # already user-facing
    if len(msg) > 180:
        return msg[:177] + "…"
    return msg


async def run_extract_task(tid: str, url: str, user_id: str | None = None):
    try:

        async def prog(e):
            await emit_event(tid, e)

        result = await extract(url, progress=prog)
        gid = uuid.uuid4().hex[:12]
        gallery = [
            m for m in (result.get("media") or [])
            if isinstance(m, str) and m.startswith("http") and ".mp4" not in m
        ]
        source = {
            "type": "url",
            "url": url,
            "source_ref": url,
            "platform": result.get("platform", "generic"),
            "pname": result.get("pname", PLATFORM_NAMES.get(detect_platform(url), "链接")),
            "title": result.get("title") or url,
            "content": result.get("content", ""),
            "segments": result.get("segments", []),
            "media": result.get("media", []),
            "gallery": gallery,
            "video_url": result.get("video_url", ""),
            "thumbnail_url": result.get("thumbnail_url", ""),
        }
        source["summary"] = (source["content"] or source["title"] or "")[:120]
        bad = video_source_unreliable(source)
        if bad:
            raise ValueError(bad)
        state, compile_meta = await compile_source_to_state(source, prog)
        save_graph(gid, source["title"], "url", url, source["content"], state, user_id=user_id)
        log_usage("ingest_url", user_id=user_id, graph_id=gid, meta=usage_meta_for_source(source))
        result_out = {
            "graph_id": gid,
            "state": state,
            "extract": {k: result.get(k) for k in ("platform", "pname", "title", "segments")},
            **compile_meta,
        }
        task_results[tid] = result_out
        task_status[tid] = "done"
        await emit_event(tid, {"type": "done", "result": result_out})
    except Exception as e:
        task_status[tid] = "error"
        friendly = user_friendly_ingest_error(e, url)
        task_results[tid] = {"message": friendly}
        await emit_event(tid, {"type": "error", "message": friendly})


IMG_PROXY_UA = "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 Chrome/131.0.0.0 Safari/537.36"


@app.get("/api/imgproxy")
async def img_proxy(url: str = Query(..., min_length=8)):
    """代理外链图片（公众号等防盗链）。"""
    if not url.startswith("http://") and not url.startswith("https://"):
        raise HTTPException(400, "invalid url")
    ref = "https://mp.weixin.qq.com/"
    if "xiaohongshu" in url or "xhscdn" in url:
        ref = "https://www.xiaohongshu.com/"
    if "twimg.com" in url or "twitter.com" in url or "x.com" in url:
        ref = "https://x.com/"
    async with httpx.AsyncClient(timeout=20, follow_redirects=True) as cl:
        r = await cl.get(url, headers={"User-Agent": IMG_PROXY_UA, "Referer": ref})
    if r.status_code != 200:
        raise HTTPException(502, f"image fetch {r.status_code}")
    ctype = r.headers.get("content-type", "image/jpeg")
    return StreamingResponse(iter([r.content]), media_type=ctype)


@app.post("/api/extract")
async def api_extract(req: ExtractRequest, request: Request):
    require_logged_in(request)
    uid = request_user_id(request)
    if quota_enforced(uid, request):
        ok, msg, _ = check_graph_create(uid, "ingest_url")
        if not ok:
            raise HTTPException(402, msg)
    tid = create_task()
    url = normalize_input_url(req.url.strip())
    asyncio.create_task(run_extract_task(tid, url, uid))
    return {"task_id": tid}


@app.get("/api/tasks/{tid}/stream")
async def task_stream(tid: str):
    async def generate():
        if tid not in task_events:
            yield f"data: {json.dumps({'type': 'error', 'message': 'task not found'})}\n\n"
            return
        while True:
            try:
                event = await asyncio.wait_for(task_events[tid].get(), timeout=30)
                yield f"data: {json.dumps(event)}\n\n"
                if event.get("type") in ("done", "error"):
                    break
            except asyncio.TimeoutError:
                yield f"data: {json.dumps({'type': 'heartbeat'})}\n\n"

    return StreamingResponse(generate(), media_type="text/event-stream")


@app.get("/api/tasks/{tid}")
async def task_status_endpoint(tid: str):
    return {"task_id": tid, "status": task_status.get(tid, "not_found"), "result": task_results.get(tid)}


# ─── Text / keyword ingest ───────────────────────────
@app.post("/api/ingest/text")
async def ingest_text(req: TextIngestRequest, request: Request):
    require_logged_in(request)
    uid = request_user_id(request)
    text = req.text.strip()
    if not text:
        raise HTTPException(400, "内容不能为空")
    is_keyword = req.mode == "keyword" or (req.mode == "auto" and len(text) < 80 and "\n" not in text)
    if quota_enforced(uid, request):
        ok, msg, _ = check_graph_create(uid, "ingest_text", {"keyword": is_keyword})
        if not ok:
            raise HTTPException(402, msg)
    gid = uuid.uuid4().hex[:12]
    source = {
        "type": "keyword" if is_keyword else "text",
        "platform": "keyword" if is_keyword else "text",
        "pname": "关键词" if is_keyword else "文本",
        "title": text[:60] if is_keyword else text[:80],
        "content": text,
        "summary": text[:80] if is_keyword else text[:200],
        "segments": [],
    }
    state, compile_meta = await compile_source_to_state(source)
    root_title = state.get("nodeDefs", {}).get(state["nodes"][0], {}).get("title", text[:60])
    source["title"] = root_title
    save_graph(gid, root_title, source["type"], text[:200], text, state, user_id=uid)
    log_usage("ingest_text", user_id=uid, graph_id=gid, meta=usage_meta_for_source(source, {"mode": req.mode, "keyword": is_keyword}))
    return {"graph_id": gid, "state": state, **compile_meta}


# ─── File upload ─────────────────────────────────────
@app.post("/api/ingest/upload")
async def ingest_upload(request: Request, file: UploadFile = File(...)):
    require_logged_in(request)
    uid = request_user_id(request)
    if quota_enforced(uid, request):
        ok, msg, _ = check_graph_create(uid, "ingest_upload")
        if not ok:
            raise HTTPException(402, msg)
    ext = Path(file.filename or "file").suffix.lower()
    fid = uuid.uuid4().hex[:12]
    dest = UPLOAD_DIR / f"{fid}{ext}"
    content_bytes = await file.read()
    dest.write_bytes(content_bytes)

    if ext in (".png", ".jpg", ".jpeg", ".gif", ".webp"):
        gid = uuid.uuid4().hex[:12]
        title = Path(file.filename or "图片").stem
        source = {"type": "image", "platform": "image", "title": title, "content": "", "summary": f"上传的图片：{file.filename}", "media_path": f"/uploads/{fid}{ext}"}
        root_id, root_def = make_root_node(source)
        root_def["hero"] = source["media_path"]
        state = default_canvas_state(root_id, root_def, source)
        save_graph(gid, title, "image", str(dest), "", state, user_id=uid)
        log_usage("ingest_upload", user_id=uid, graph_id=gid, meta=usage_meta_for_source(source, {"ext": ext}))
        return {"graph_id": gid, "state": state}

    if ext in (".txt", ".md", ".json"):
        text = content_bytes.decode("utf-8", errors="replace")
        req = TextIngestRequest(text=text, mode="text")
        return await ingest_text(req, request)

    raise HTTPException(400, f"不支持的文件类型: {ext}")


# ─── Chat (Curio agent + SSE) ────────────────────────
def _load_chat_context(req: ChatRequest) -> tuple[dict, dict, str]:
    with sqlite3.connect(DB_PATH) as db:
        row = db.execute("SELECT state_json, source_content FROM graphs WHERE id=?", [req.graph_id]).fetchone()
    if not row:
        raise HTTPException(404, "图谱不存在")
    state = json.loads(row[0])
    source_content = row[1] or ""
    node_defs = state.get("nodeDefs", {})
    node = node_defs.get(req.node_id, {})
    known = "\n".join(f"- {k}: {v.get('title', k)}" for k, v in list(node_defs.items())[:30])
    src = state.get("source") or {}
    has_video = bool(normalize_video_url(src.get("video_url") or node.get("video") or ""))
    root_id = (state.get("nodes") or [None])[0]
    root_title = (node_defs.get(root_id) or {}).get("title", "") if root_id else ""
    ctx = {
        "graph_id": req.graph_id,
        "node_id": req.node_id,
        "question": req.question,
        "node": node,
        "known_nodes": known,
        "source_content": req.source_content or source_content,
        "source_title": src.get("title") or "",
        "root_title": root_title,
        "is_root_node": req.node_id == root_id,
        "thread_history": req.thread_history,
        "has_video": has_video,
    }
    return ctx, state, source_content


def _persist_node_hero(graph_id: str, state: dict, source_content: str, node_id: str, url: str):
    node_defs = state.get("nodeDefs", {})
    if node_id not in node_defs or not url:
        return
    node_defs[node_id]["hero"] = url
    state["nodeDefs"] = node_defs
    save_graph(
        graph_id,
        state.get("source", {}).get("title", "未命名"),
        state.get("source", {}).get("type", "?"),
        state.get("source", {}).get("url", ""),
        source_content,
        state,
    )


def _sse(data: dict) -> str:
    return f"data: {json.dumps(data, ensure_ascii=False)}\n\n"


@app.post("/api/chat/stream")
async def api_chat_stream(req: ChatRequest, request: Request):
    uid = request_user_id(request)
    if quota_enforced(uid, request):
        ok, msg, _ = check_chat(uid, req.graph_id)
        if not ok:
            async def blocked():
                yield _sse({"error": msg, "quota": True})
            return StreamingResponse(blocked(), media_type="text/event-stream")

    async def generate():
        try:
            ctx, state, source_content = _load_chat_context(req)
        except HTTPException as e:
            yield _sse({"error": e.detail})
            return
        try:
            async for ev in run_curio_agent(ctx, nest_slug_fn(req.node_id)):
                if ev.get("done") and ev.get("node_image"):
                    _persist_node_hero(req.graph_id, state, source_content, req.node_id, ev["node_image"])
                if ev.get("done") and not ev.get("error"):
                    log_usage("chat", user_id=uid, graph_id=req.graph_id, meta={"node_id": req.node_id})
                yield _sse(ev)
        except Exception as e:
            yield _sse({"error": str(e)[:300]})

    return StreamingResponse(generate(), media_type="text/event-stream")


@app.post("/api/chat")
async def api_chat(req: ChatRequest):
    """Non-streaming fallback — collects full Curio agent run."""
    ctx, state, source_content = _load_chat_context(req)
    final = None
    async for ev in run_curio_agent(ctx, nest_slug_fn(req.node_id)):
        if ev.get("error"):
            raise HTTPException(502, ev["error"])
        if ev.get("done"):
            final = ev
    if not final:
        raise HTTPException(502, "Curio 无响应")
    if final.get("node_image"):
        _persist_node_hero(req.graph_id, state, source_content, req.node_id, final["node_image"])
    return final


def _graph_owner_id(row) -> str | None:
    return row[8] if len(row) > 8 else None


def _assert_graph_access(row, user: dict | None):
    if not row:
        raise HTTPException(404, "图谱不存在")
    owner = _graph_owner_id(row)
    if not owner:
        return
    if not user:
        raise HTTPException(401, "请先登录")
    if user.get("is_admin"):
        return
    if owner != user.get("id"):
        raise HTTPException(403, "无权访问此图谱")


# ─── Graph CRUD ──────────────────────────────────────
def _graph_list_meta(state_json_str: str) -> tuple[int, dict | None]:
    try:
        st = json.loads(state_json_str)
        nodes = st.get("nodes") or []
        positions = st.get("positions") or {}
        node_defs = st.get("nodeDefs") or {}
        points = []
        for nid in nodes[:24]:
            p = positions.get(nid)
            if not p:
                continue
            nd = node_defs.get(nid) or {}
            points.append(
                {
                    "id": nid,
                    "x": p["x"],
                    "y": p["y"],
                    "size": nd.get("size", 72),
                    "label": (nd.get("title") or nd.get("label") or "")[:8],
                }
            )
        edges = [
            {"from": c["from"], "to": c["to"]}
            for c in (st.get("connections") or [])[:40]
            if c.get("from") and c.get("to")
        ]
        return len(nodes), {"points": points, "edges": edges}
    except Exception:
        return 0, None


@app.get("/api/graphs")
async def list_graphs(request: Request, limit: int = Query(200, ge=1, le=500)):
    user = request_user(request)
    cap = min(limit, 500)
    with sqlite3.connect(DB_PATH) as db:
        if user and user.get("is_admin"):
            rows = db.execute(
                "SELECT id, title, source_type, source_ref, updated_at, state_json FROM graphs ORDER BY updated_at DESC LIMIT ?",
                [cap],
            ).fetchall()
            total = db.execute("SELECT COUNT(*) FROM graphs").fetchone()[0]
        elif user:
            rows = db.execute(
                """SELECT id, title, source_type, source_ref, updated_at, state_json FROM graphs
                   WHERE user_id=? OR user_id IS NULL OR user_id=''
                   ORDER BY updated_at DESC LIMIT ?""",
                [user["id"], cap],
            ).fetchall()
            total = db.execute(
                """SELECT COUNT(*) FROM graphs
                   WHERE user_id=? OR user_id IS NULL OR user_id=''""",
                [user["id"]],
            ).fetchone()[0]
        else:
            rows = []
            total = 0
    out = []
    for r in rows:
        node_count, preview = _graph_list_meta(r[5])
        out.append(
            {
                "id": r[0],
                "title": r[1],
                "source_type": r[2],
                "source_ref": r[3],
                "updated_at": r[4],
                "node_count": node_count,
                "preview": preview,
            }
        )
    return {"graphs": out, "total": total, "limit": cap}


@app.post("/api/graphs/claim")
async def claim_graphs(req: GraphClaimRequest, request: Request):
    """Attach orphan graphs (no owner) to the logged-in user — e.g. created before login."""
    user = request_user(request)
    if not user:
        raise HTTPException(401, "请先登录")
    uid = user["id"]
    ids = [str(i).strip() for i in (req.ids or []) if str(i).strip()][:200]
    if not ids:
        return {"claimed": 0, "ids": []}
    claimed: list[str] = []
    with sqlite3.connect(DB_PATH) as db:
        for gid in ids:
            cur = db.execute(
                """UPDATE graphs SET user_id=?, updated_at=?
                   WHERE id=? AND (user_id IS NULL OR user_id='')""",
                [uid, now_iso(), gid],
            )
            if cur.rowcount:
                claimed.append(gid)
    if claimed:
        log_usage("claim_graphs", user_id=uid, meta={"count": len(claimed)})
    return {"claimed": len(claimed), "ids": claimed}


@app.get("/api/graphs/{gid}")
async def get_graph(gid: str, request: Request):
    with sqlite3.connect(DB_PATH) as db:
        r = db.execute("SELECT * FROM graphs WHERE id=?", [gid]).fetchone()
    if not r:
        raise HTTPException(404, "图谱不存在")
    _assert_graph_access(r, request_user(request))
    return {
        "id": r[0],
        "title": r[1],
        "source_type": r[2],
        "source_ref": r[3],
        "source_content": r[4],
        "state": json.loads(r[5]),
        "created_at": r[6],
        "updated_at": r[7],
    }


@app.patch("/api/graphs/{gid}/meta")
async def patch_graph_meta(gid: str, req: GraphMetaPatch):
    if not req.title or not req.title.strip():
        raise HTTPException(400, "标题不能为空")
    title = req.title.strip()[:120]
    with sqlite3.connect(DB_PATH) as db:
        row = db.execute("SELECT state_json FROM graphs WHERE id=?", [gid]).fetchone()
        if not row:
            raise HTTPException(404, "图谱不存在")
        state = json.loads(row[0])
        source = state.get("source") or {}
        source["title"] = title
        state["source"] = source
        ts = now_iso()
        db.execute(
            "UPDATE graphs SET title=?, state_json=?, updated_at=? WHERE id=?",
            [title, json.dumps(state, ensure_ascii=False), ts, gid],
        )
    return {"ok": True, "title": title}


@app.get("/api/graphs/{gid}/export")
async def export_graph(gid: str):
    with sqlite3.connect(DB_PATH) as db:
        r = db.execute("SELECT * FROM graphs WHERE id=?", [gid]).fetchone()
    if not r:
        raise HTTPException(404, "图谱不存在")
    st = json.loads(r[5])
    return {
        "export_version": 1,
        "exported_at": now_iso(),
        "id": r[0],
        "title": r[1],
        "source_type": r[2],
        "source_ref": r[3],
        "source_content": r[4] or (st.get("source") or {}).get("content") or "",
        "state": st,
    }


@app.post("/api/graphs/import")
async def import_graph(req: GraphImportRequest, request: Request):
    st = req.state
    source = st.get("source") or {}
    is_demo = source.get("type") == "demo"
    uid = request_user_id(request)
    if not is_demo:
        require_logged_in(request)
        if quota_enforced(uid, request):
            ok, msg, _ = check_graph_create(uid, "ingest_text", {"keyword": False})
            if not ok:
                raise HTTPException(402, msg)
    if not isinstance(st.get("nodes"), list) or len(st["nodes"]) < 1:
        raise HTTPException(400, "无效的图谱数据：缺少 nodes")
    if not isinstance(st.get("positions"), dict):
        raise HTTPException(400, "无效的图谱数据：缺少 positions")
    title = (req.title or source.get("title") or "导入的探索")[:120]
    gid = uuid.uuid4().hex[:12]
    source["title"] = title
    st["source"] = source
    st.setdefault("connections", [])
    st.setdefault("nodeDefs", {})
    st.setdefault("nodeOrder", list(st["nodes"]))
    st.setdefault("chats", {})
    st.setdefault("collapsedNodes", {})
    for nid in st["nodes"]:
        if nid not in st["nodeDefs"]:
            st["nodeDefs"][nid] = {"id": nid, "title": nid, "label": nid, "icon": "📌", "size": 72}
        if nid not in st["positions"]:
            st["positions"][nid] = {"x": 2000, "y": 1400}
    save_graph(
        gid,
        title,
        source.get("type") or "import",
        source.get("url") or source.get("source_ref") or title,
        source.get("content") or "",
        st,
        user_id=uid if not is_demo else None,
    )
    if not is_demo:
        log_usage("ingest_text", user_id=uid, graph_id=gid, meta=usage_meta_for_source(source, {"mode": "import", "keyword": False}))
    st["sessionId"] = gid
    return {"graph_id": gid, "state": st}


@app.post("/api/graphs/{gid}/duplicate")
async def duplicate_graph(gid: str, request: Request):
    with sqlite3.connect(DB_PATH) as db:
        r = db.execute("SELECT * FROM graphs WHERE id=?", [gid]).fetchone()
    if not r:
        raise HTTPException(404, "图谱不存在")
    _assert_graph_access(r, request_user(request))
    state = json.loads(r[5])
    new_gid = uuid.uuid4().hex[:12]
    title = f"{r[1] or '探索'} (副本)"[:120]
    source = state.get("source") or {}
    source["title"] = title
    state["source"] = source
    save_graph(new_gid, title, r[2] or "import", r[3] or "", r[4] or "", state, user_id=request_user_id(request))
    state["sessionId"] = new_gid
    return {"graph_id": new_gid, "state": state}


@app.delete("/api/graphs/{gid}")
async def delete_graph(gid: str):
    with sqlite3.connect(DB_PATH) as db:
        cur = db.execute("DELETE FROM graphs WHERE id=?", [gid])
        if cur.rowcount == 0:
            raise HTTPException(404, "图谱不存在")
    return {"ok": True}


@app.put("/api/graphs/{gid}")
async def update_graph(gid: str, req: GraphSaveRequest, request: Request):
    uid = request_user_id(request)
    with sqlite3.connect(DB_PATH) as db:
        r = db.execute("SELECT id, title, user_id FROM graphs WHERE id=?", [gid]).fetchone()
        if not r:
            raise HTTPException(404, "图谱不存在")
        owner = r[2] if len(r) > 2 else None
        if owner and uid and owner != uid:
            u = request_user(request)
            if not (u and u.get("is_admin")):
                raise HTTPException(403, "无权修改此图谱")
        state = req.state
        state["sessionId"] = gid
        title = (state.get("source") or {}).get("title") or r[1] or "未命名"
        if uid and (not owner or owner in ("", None)):
            db.execute(
                "UPDATE graphs SET title=?, state_json=?, updated_at=?, user_id=? WHERE id=?",
                [title[:120], json.dumps(state, ensure_ascii=False), now_iso(), uid, gid],
            )
        else:
            db.execute(
                "UPDATE graphs SET title=?, state_json=?, updated_at=? WHERE id=?",
                [title[:120], json.dumps(state, ensure_ascii=False), now_iso(), gid],
            )
    return {"ok": True}


# 首页「试试这些」——贴近当下热点 +  evergreen 话题
STARTER_EXAMPLES = [
    "2026 世界杯怎么看",
    "高考志愿怎么填",
    "毕业季第一份工作怎么选",
    "AI Agent 为什么突然火了",
    "vibe coding 是什么",
    "Transformer 怎么工作",
    "如何系统学一门新技能",
    "RAG 和微调有什么区别",
    "扩散模型为什么能画图",
    "注意力机制直觉解释",
    "第一性原理怎么用",
    "费曼学习法具体步骤",
    "为什么睡眠对记忆这么重要",
    "如何读一篇 AI 论文",
    "Chain-of-Thought 是什么",
    "OpenAI o 系列在解决什么问题",
    "强化学习从哪入门",
]


def starter_examples(n: int = 3, d: date | None = None, offset: int = 0) -> list[str]:
    pool = STARTER_EXAMPLES
    if not pool:
        return []
    n = max(1, min(n, len(pool)))
    day = d or date.today()
    start = (day.toordinal() + offset) % len(pool)
    return [pool[(start + i) % len(pool)] for i in range(n)]


# 首页 Hero — Ethan 选定 C 为默认；其余为同气质备选（暂不轮换）
DEFAULT_HERO_SLOGAN_ID = "internalize"

HERO_SLOGANS = [
    {
        "id": "internalize",
        "lines": ["看了不等于学了，", "除非内化成你的结构"],
        "em_line": 1,
        "sub": "视频、文章、一个概念——都能在同一张画布上长出来。",
    },
    {
        "id": "flow",
        "lines": ["学习可以自然流淌，", "不必硬背、不必痛苦"],
        "em_line": 1,
        "sub": "好奇往哪走，结构往哪长——像脑子本来就会的那样。",
    },
    {
        "id": "brain",
        "lines": ["大脑天生记画面和关系，", "不是记一大段字"],
        "em_line": 1,
        "sub": "图、空间、发散——符合人类习惯，这才叫真正的内化。",
    },
    {
        "id": "real",
        "lines": ["学得爽，", "才是真的在学"],
        "em_line": 1,
        "sub": "没有及格线，没有压力。你想搞懂哪块，就从哪块长出去。",
    },
    {
        "id": "reform",
        "lines": ["改革的不该是题库，", "是怎么把知识留下来"],
        "em_line": 1,
        "sub": "人类知识的传承，不该止于「我看过了」。",
    },
    {
        "id": "habit",
        "lines": ["发散，", "本来就是人的习惯"],
        "em_line": 1,
        "sub": "顺着好奇问下去，一张地图自然长出来——自然而然，没有压力。",
    },
]


SUPPORTED_PLATFORMS = [
    {"id": "bilibili", "name": "哔哩哔哩", "logo": "/assets/platforms/bilibili.svg"},
    {"id": "youtube", "name": "YouTube", "logo": "/assets/platforms/youtube.svg"},
    {"id": "wechat", "name": "公众号", "logo": "/assets/platforms/wechat.svg"},
    {"id": "wechat_video", "name": "视频号", "logo": "/assets/platforms/channels.svg"},
    {"id": "xiaohongshu", "name": "小红书", "logo": "/assets/platforms/xiaohongshu.svg"},
    {"id": "twitter", "name": "X", "logo": "/assets/platforms/x.svg"},
]


def hero_slogan_by_id(sid: str) -> dict:
    for s in HERO_SLOGANS:
        if s["id"] == sid:
            return s
    return HERO_SLOGANS[0]


def hero_slogan_for_day(d: date | None = None) -> dict:
    day = d or date.today()
    return HERO_SLOGANS[day.toordinal() % len(HERO_SLOGANS)]


def daily_topic_picks(n: int = 4) -> list[str]:
    """Deprecated alias — landing uses fixed starter examples."""
    return starter_examples(min(n, 3))


def graph_preview_from_state(state: dict) -> dict:
    positions = state.get("positions") or {}
    connections = state.get("connections") or []
    nodes = state.get("nodes") or []
    node_defs = state.get("nodeDefs") or {}
    points = []
    for nid in nodes:
        p = positions.get(nid)
        if not p:
            continue
        d = node_defs.get(nid) or {}
        points.append({
            "id": nid,
            "x": p.get("x", 0),
            "y": p.get("y", 0),
            "label": (d.get("title") or d.get("label") or nid)[:24],
            "size": d.get("size", 72),
        })
    return {
        "node_count": len(nodes),
        "conn_count": len(connections),
        "points": points[:28],
        "edges": [{"from": c.get("from"), "to": c.get("to")} for c in connections[:36] if c.get("from") and c.get("to")],
    }


def topic_case_preview(seed: int, title: str = "主题", n: int = 8) -> dict:
    rng = random.Random(seed)
    cx, cy = 2000.0, 1400.0
    points = [{"id": "root", "x": cx, "y": cy, "label": title[:8], "size": 78}]
    edges = []
    for i in range(max(1, n - 1)):
        ang = (i / max(1, n - 1)) * 6.28318
        r = 168 + rng.randint(-24, 36)
        nid = f"n{i}"
        points.append({
            "id": nid,
            "x": cx + r * math.cos(ang),
            "y": cy + r * math.sin(ang),
            "label": "·",
            "size": 66 + rng.randint(0, 6),
        })
        edges.append({"from": "root", "to": nid})
    return {
        "node_count": len(points),
        "conn_count": len(edges),
        "points": points,
        "edges": edges,
    }


HOT_TOPIC_CASES = [
    {
        "id": "topic:worldcup",
        "title": "2026 世界杯怎么看",
        "platform": "topic",
        "platform_name": "热点话题",
        "topic_query": "2026世界杯赛制与看点",
        "preview_seed": 202606,
    },
    {
        "id": "topic:gaokao",
        "title": "高考志愿怎么填",
        "platform": "topic",
        "platform_name": "热点话题",
        "topic_query": "2025年高考志愿填报要点",
        "preview_seed": 202506,
    },
    {
        "id": "topic:graduation",
        "title": "毕业季怎么选第一份工作",
        "platform": "topic",
        "platform_name": "热点话题",
        "topic_query": "应届生第一份工作怎么选",
        "preview_seed": 20260614,
    },
    {
        "id": "topic:ai-agent",
        "title": "AI Agent 为什么突然火了",
        "platform": "topic",
        "platform_name": "热点话题",
        "topic_query": "AI Agent 是什么 为什么突然火了",
        "preview_seed": 202602,
    },
]


KARPATHY_SHOWCASE_PREVIEW = {
    "node_count": 8,
    "conn_count": 9,
    "points": [
        {"id": "karpathy", "x": 2000, "y": 1400, "label": "Karpathy", "size": 78},
        {"id": "nanogpt", "x": 2000, "y": 1100, "label": "nanoGPT", "size": 72},
        {"id": "cs231n", "x": 2235, "y": 1213, "label": "CS231n", "size": 72},
        {"id": "tesla", "x": 2292, "y": 1467, "label": "Tesla AI", "size": 72},
        {"id": "youtube", "x": 2130, "y": 1670, "label": "教学视频", "size": 72},
        {"id": "llmwiki", "x": 1870, "y": 1670, "label": "LLM 方法论", "size": 68},
        {"id": "sw2", "x": 1708, "y": 1467, "label": "Software 2.0", "size": 68},
        {"id": "llmc", "x": 1765, "y": 1213, "label": "LLM 课程", "size": 68},
    ],
    "edges": [
        {"from": "karpathy", "to": "nanogpt"}, {"from": "karpathy", "to": "cs231n"},
        {"from": "karpathy", "to": "tesla"}, {"from": "karpathy", "to": "youtube"},
        {"from": "karpathy", "to": "llmwiki"}, {"from": "karpathy", "to": "sw2"},
        {"from": "karpathy", "to": "llmc"}, {"from": "nanogpt", "to": "llmc"},
        {"from": "tesla", "to": "sw2"},
    ],
}


@app.get("/api/landing")
async def landing_feed():
    """Daily topic picks + showcase case previews for the homepage."""
    day = date.today()
    # 按日期轮换热点顺序，避免永远只显示第一个
    rot = day.toordinal() % len(HOT_TOPIC_CASES)
    ordered_topics = HOT_TOPIC_CASES[rot:] + HOT_TOPIC_CASES[:rot]
    cases = []
    for tc in ordered_topics:
        prev = topic_case_preview(tc["preview_seed"], tc["title"])
        cases.append({**tc, "preview": prev})
    with sqlite3.connect(DB_PATH) as db:
        rows = db.execute(
            "SELECT id, title, source_type, state_json FROM graphs ORDER BY updated_at DESC LIMIT 4",
        ).fetchall()
    for gid, title, source_type, state_json in rows:
        if len(cases) >= 6:
            break
        try:
            st = json.loads(state_json)
        except json.JSONDecodeError:
            continue
        if len(st.get("nodes") or []) < 2:
            continue
        src = st.get("source") or {}
        plat = src.get("platform") or source_type or "generic"
        cases.append({
            "id": gid,
            "title": (title or src.get("title") or "未命名探索")[:80],
            "platform": plat,
            "platform_name": PLATFORM_NAMES.get(plat, "探索"),
            "preview": graph_preview_from_state(st),
        })
    return {
        "date": date.today().isoformat(),
        "hero_slogan": hero_slogan_for_day(),
        "hero_slogans": HERO_SLOGANS,
        "starter_pool": STARTER_EXAMPLES,
        "starter_examples": starter_examples(3),
        "daily_picks": starter_examples(3),
        "supported_platforms": SUPPORTED_PLATFORMS,
        "cases": cases[:6],
    }


@app.post("/api/graphs/demo")
async def load_demo():
    """Return Karpathy demo state without persisting."""
    return {"demo": True}


@app.post("/api/agent-search")
async def agent_search(req: AgentSearchRequest):
    items = await search_web(req.query.strip(), limit=6)
    return {"query": req.query, "items": items}


@app.post("/api/graphs/{gid}/enrich-images")
async def enrich_graph_images(gid: str):
    with sqlite3.connect(DB_PATH) as db:
        row = db.execute("SELECT state_json, source_content FROM graphs WHERE id=?", [gid]).fetchone()
    if not row:
        raise HTTPException(404, "图谱不存在")
    state = json.loads(row[0])
    video_url = normalize_video_url(state.get("source", {}).get("video_url") or "")
    if video_url:
        enriched = await enrich_state_video_frames(state)
        save_graph(
            gid,
            state.get("source", {}).get("title", "未命名"),
            state.get("source", {}).get("type", "?"),
            state.get("source", {}).get("url", ""),
            row[1] or "",
            state,
        )
        return {"enriched": enriched, "state": state, "mode": "video_frames"}

    return {"enriched": 0, "state": state, "mode": "none"}


@app.get("/api/search-image")
async def api_search_image(q: str = Query(..., min_length=1)):
    url = await fetch_image(q)
    return {"url": url, "query": q}


@app.post("/api/node-image")
async def apply_node_image(req: NodeImageRequest):
    with sqlite3.connect(DB_PATH) as db:
        row = db.execute("SELECT state_json FROM graphs WHERE id=?", [req.graph_id]).fetchone()
    if not row:
        raise HTTPException(404, "图谱不存在")
    state = json.loads(row[0])
    node_defs = state.get("nodeDefs", {})
    node = node_defs.get(req.node_id)
    if not node:
        raise HTTPException(404, "节点不存在")

    video_url = normalize_video_url(state.get("source", {}).get("video_url") or node.get("video") or "")
    if not video_url:
        raise HTTPException(404, "无视频源，无法截帧")

    await enrich_state_video_frames(state)
    node = state.get("nodeDefs", {}).get(req.node_id, {})
    if not node.get("hero"):
        raise HTTPException(404, "视频截帧失败")
    save_graph(
        req.graph_id,
        state.get("source", {}).get("title", "未命名"),
        state.get("source", {}).get("type", "?"),
        "",
        state.get("source", {}).get("content", ""),
        state,
    )
    return {
        "urls": node.get("gallery") or [node["hero"]],
        "gallery": node.get("gallery") or [node["hero"]],
        "url": node["hero"],
        "node_id": req.node_id,
    }


@app.post("/api/auth/send-code")
async def auth_send_code(req: AuthSendCodeRequest):
    try:
        return send_login_code(req.email)
    except ValueError as e:
        raise HTTPException(400, str(e))


@app.post("/api/auth/verify")
async def auth_verify(req: AuthVerifyRequest):
    try:
        return verify_login_code(req.email, req.code)
    except ValueError as e:
        raise HTTPException(400, str(e))


@app.post("/api/auth/login")
async def auth_login(req: AuthLoginRequest):
    try:
        return login_with_password(req.email, req.password)
    except ValueError as e:
        raise HTTPException(400, str(e))


class DeployApplyRequest(BaseModel):
    password: str
    url: str


@app.post("/api/admin/apply-update")
async def admin_apply_update(req: DeployApplyRequest):
    """One-shot remote update: admin password + tarball URL (HTTPS only)."""
    expected = env_key("CURIO_ADMIN_PASSWORD") or env_key("DEPLOY_TOKEN")
    if not expected or req.password != expected:
        raise HTTPException(403, "forbidden")
    url = (req.url or "").strip()
    if not url.startswith("https://"):
        raise HTTPException(400, "url must be https")
    import subprocess
    import tarfile
    import tempfile

    tmp = Path(tempfile.mkdtemp(prefix="curio-up-"))
    arc = tmp / "update.tar.gz"
    try:
        async with httpx.AsyncClient(timeout=120, follow_redirects=True) as cl:
            r = await cl.get(url)
            if r.status_code != 200:
                raise HTTPException(400, f"download failed: {r.status_code}")
            arc.write_bytes(r.content)
        with tarfile.open(arc, "r:gz") as tar:
            for member in tar.getmembers():
                name = member.name.replace("\\", "/")
                if name.startswith("/") or ".." in name.split("/"):
                    continue
                tar.extract(member, ROOT)
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(500, str(e)[:200])
    finally:
        import shutil
        shutil.rmtree(tmp, ignore_errors=True)
    return {"ok": True, "message": "extracted; restart pm2/uvicorn to load"}


@app.get("/api/config")
async def api_config():
    return {
        "quota_enforce": env_key("QUOTA_ENFORCE") == "1",
        "auth_required": env_key("QUOTA_ENFORCE") == "1",
        "product": "Curio 知所",
        "contact_email": env_key("CURIO_CONTACT_EMAIL") or "yzc_2024@163.com",
    }


@app.get("/api/auth/me")
async def auth_me(request: Request):
    user = request_user(request)
    if not user:
        return {"user": None}
    return {"user": user}


@app.post("/api/auth/logout")
async def auth_logout(request: Request):
    logout_token(_bearer_token(request))
    return {"ok": True}


def require_admin(request: Request) -> dict:
    user = request_user(request)
    if not user:
        raise HTTPException(401, "请先登录管理员账号")
    if not user.get("is_admin"):
        raise HTTPException(403, "需要管理员权限")
    return user


def _normalize_admin_email(email: str | None) -> str:
    return (email or "").strip().lower()


def _admin_ensure_user(db: sqlite3.Connection, email: str) -> str:
    email = _normalize_admin_email(email)
    if not email or "@" not in email:
        raise HTTPException(400, "请输入有效邮箱")
    row = db.execute("SELECT id FROM users WHERE email=?", [email]).fetchone()
    if row:
        return row[0]
    uid = uuid.uuid4().hex[:16]
    db.execute(
        "INSERT INTO users (id, email, is_admin, created_at) VALUES (?,?,0,?)",
        [uid, email, now_iso()],
    )
    return uid


@app.get("/api/admin/users")
async def api_admin_users(request: Request, q: str = "", limit: int = 50):
    require_admin(request)
    needle = f"%{_normalize_admin_email(q)}%"
    cap = max(1, min(int(limit or 50), 200))
    where = "WHERE u.email LIKE ?" if q.strip() else ""
    params = [needle, cap] if where else [cap]
    with sqlite3.connect(DB_PATH) as db:
        rows = db.execute(
            f"""SELECT u.id, u.email, u.is_admin, u.created_at,
                      MAX(s.created_at) AS last_login,
                      e.tier, e.expires_at,
                      COUNT(DISTINCT g.id) AS graph_count,
                      COUNT(DISTINCT CASE WHEN ul.action='chat' THEN ul.id END) AS chat_count
                 FROM users u
                 LEFT JOIN sessions s ON s.user_id = u.id
                 LEFT JOIN entitlements e ON e.user_id = u.id
                 LEFT JOIN graphs g ON g.user_id = u.id
                 LEFT JOIN usage_logs ul ON ul.user_id = u.id
                 {where}
                GROUP BY u.id
                ORDER BY COALESCE(last_login, u.created_at) DESC
                LIMIT ?""",
            params,
        ).fetchall()
    users = []
    for row in rows:
        st = get_quota_status(row[0]).to_dict()
        users.append({
            "id": row[0],
            "email": row[1],
            "is_admin": bool(row[2]),
            "created_at": row[3],
            "last_login": row[4],
            "tier": row[5] or st.get("tier", "free"),
            "expires_at": row[6],
            "graph_count": int(row[7] or 0),
            "chat_count": int(row[8] or 0),
            "quota": st,
        })
    return {"users": users}


@app.get("/api/admin/users/{user_id}/usage")
async def api_admin_user_usage(user_id: str, request: Request):
    require_admin(request)
    with sqlite3.connect(DB_PATH) as db:
        user = db.execute("SELECT id, email, is_admin, created_at FROM users WHERE id=?", [user_id]).fetchone()
        if not user:
            raise HTTPException(404, "用户不存在")
        usage_rows = db.execute(
            """SELECT action, graph_id, meta_json, created_at
                 FROM usage_logs WHERE user_id=?
                ORDER BY created_at DESC LIMIT 100""",
            [user_id],
        ).fetchall()
        grants = db.execute(
            """SELECT kind, amount, source, note, operator, created_at
                 FROM quota_grants WHERE user_id=?
                ORDER BY created_at DESC LIMIT 100""",
            [user_id],
        ).fetchall()
        graphs = db.execute(
            """SELECT id, title, source_type, created_at, updated_at
                 FROM graphs WHERE user_id=?
                ORDER BY updated_at DESC LIMIT 50""",
            [user_id],
        ).fetchall()
    return {
        "user": {"id": user[0], "email": user[1], "is_admin": bool(user[2]), "created_at": user[3]},
        "quota": get_quota_status(user_id).to_dict(),
        "usage": [
            {"action": r[0], "graph_id": r[1], "meta": json.loads(r[2] or "{}"), "created_at": r[3]}
            for r in usage_rows
        ],
        "grants": [
            {"kind": r[0], "amount": r[1], "source": r[2], "note": r[3], "operator": r[4], "created_at": r[5]}
            for r in grants
        ],
        "graphs": [
            {"id": r[0], "title": r[1], "source_type": r[2], "created_at": r[3], "updated_at": r[4]}
            for r in graphs
        ],
    }


@app.post("/api/admin/grant")
async def api_admin_grant(req: AdminGrantRequest, request: Request):
    admin = require_admin(request)
    kind = (req.kind or "").strip()
    amount = int(req.amount or 0)
    source = (req.source or "admin").strip()[:40]
    note = (req.note or "").strip()[:500]
    operator = admin.get("email") or admin.get("id")
    ts = now_iso()
    with sqlite3.connect(DB_PATH) as db:
        uid = (req.user_id or "").strip()
        if not uid:
            uid = _admin_ensure_user(db, req.email or "")
        elif not db.execute("SELECT 1 FROM users WHERE id=?", [uid]).fetchone():
            raise HTTPException(404, "用户不存在")

        if kind == "credit":
            if amount <= 0:
                raise HTTPException(400, "credit 必须为正数")
            db.execute(
                """INSERT INTO quota_grants (user_id, kind, amount, source, note, operator, created_at)
                   VALUES (?,?,?,?,?,?,?)""",
                [uid, "credit", amount, source, note, operator, ts],
            )
        elif kind == "trial_days":
            if amount <= 0:
                raise HTTPException(400, "天数必须为正数")
            row = db.execute("SELECT tier, expires_at FROM entitlements WHERE user_id=?", [uid]).fetchone()
            current = datetime.now()
            if row and row[1]:
                try:
                    current = max(current, datetime.fromisoformat(row[1]))
                except Exception:
                    pass
            expires_at = (current + timedelta(days=amount)).isoformat()
            db.execute(
                """INSERT INTO entitlements (user_id, tier, expires_at, source, note, operator, updated_at)
                   VALUES (?, 'trial', ?, ?, ?, ?, ?)
                   ON CONFLICT(user_id) DO UPDATE SET
                     tier='trial', expires_at=excluded.expires_at, source=excluded.source,
                     note=excluded.note, operator=excluded.operator, updated_at=excluded.updated_at""",
                [uid, expires_at, source, note, operator, ts],
            )
            db.execute(
                """INSERT INTO quota_grants (user_id, kind, amount, source, note, operator, created_at)
                   VALUES (?,?,?,?,?,?,?)""",
                [uid, "trial_days", amount, source, note, operator, ts],
            )
        elif kind == "admin":
            db.execute("UPDATE users SET is_admin=? WHERE id=?", [1 if amount else 0, uid])
        else:
            raise HTTPException(400, "kind 必须是 credit / trial_days / admin")
    return {"ok": True, "user_id": uid, "quota": get_quota_status(uid).to_dict()}


@app.get("/api/quota")
async def api_quota(request: Request):
    """免费额度状态（前端展示「还可生成 X 张 / 还可生长 Y 次」）。"""
    uid = request_user_id(request)
    out = get_quota_status(uid).to_dict()
    user = request_user(request)
    if user:
        out["user"] = {"email": user.get("email"), "is_admin": user.get("is_admin")}
    return out


@app.get("/api/health")
async def health():
    return {
        "status": "ok",
        "llm": bool(DEEPSEEK_KEY),
        "soniox": bool(SONIOX_KEY),
        "uptime_seconds": round(time.time() - _START_TIME, 1),
    }


# ─── Static ──────────────────────────────────────────
(ROOT / "assets").mkdir(exist_ok=True)
(ROOT / "deck" / "assets").mkdir(parents=True, exist_ok=True)
app.mount("/uploads", StaticFiles(directory=str(UPLOAD_DIR)), name="uploads")
app.mount("/cache", StaticFiles(directory=str(CACHE_DIR)), name="cache")
app.mount("/assets", StaticFiles(directory=str(ROOT / "assets")), name="assets")
app.mount("/deck/assets", StaticFiles(directory=str(ROOT / "deck" / "assets")), name="deck_assets")


@app.get("/deck")
async def deck_page():
    return HTMLResponse((ROOT / "deck" / "zh.html").read_text(encoding="utf-8"))


@app.get("/deck/en")
async def deck_page_en():
    return HTMLResponse((ROOT / "deck" / "index.html").read_text(encoding="utf-8"))


@app.get("/admin")
async def admin_page():
    return HTMLResponse((ROOT / "admin.html").read_text(encoding="utf-8"))


@app.get("/")
async def index():
    html = (ROOT / "knowledge-graph.html").read_text(encoding="utf-8")
    if CURIO_BASE_PATH and 'name="curio-base"' not in html:
        html = html.replace(
            "<head>",
            f'<head>\n<meta name="curio-base" content="{CURIO_BASE_PATH}">',
            1,
        )
    return HTMLResponse(html)


if __name__ == "__main__":
    import uvicorn

    uvicorn.run("server:app", host="0.0.0.0", port=PORT, reload=True)
