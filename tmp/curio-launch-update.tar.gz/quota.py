"""
Curio 知所 · 权益 / credit 配额

内部用 credit 对齐真实成本，前端翻译成「约几张 / 几次」。
余额不落库，始终由基础额度 + 赠送 - usage_logs 消耗派生。
"""

from __future__ import annotations

import json
import math
import sqlite3
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path

from auth import is_admin_user

# ─── credit 锚定（内测 · v4-pro）──────────────────────
USD_CNY = 7.2
CREDIT_RMB = 0.05
LLM_MODEL_TIER = "v4-pro"

CREDIT_COSTS = {
    "ingest_keyword": 3,
    "ingest_text": 4,
    "ingest_url": 5,
    "ingest_upload": 5,
    "ingest_video_base": 3,
    "ingest_video_per_min": 2,
    "chat": 4,
    "browse": 0,
}

FREE_BASE_CREDITS = 150
DISPLAY_GRAPH_CREDITS = 13
DEFAULT_VIDEO_MINUTES = 5

RECHARGE_PACKS = [
    {"rmb": 9.9, "credits": 200, "label": "约 50 张短文网 / 8 条 10 分钟视频"},
    {"rmb": 29, "credits": 650, "label": "约 160 张短文网 / 28 条 10 分钟视频"},
    {"rmb": 59, "credits": 1500, "label": "重度探索 · 约 375 张短文网"},
]

# 兼容旧前端字段；实际限制已改为 credit。
FREE_GRAPH_CREATES = FREE_BASE_CREDITS // DISPLAY_GRAPH_CREDITS
FREE_CHAT_FIRST_GRAPH = 999
FREE_CHAT_OTHER_GRAPHS = FREE_BASE_CREDITS // CREDIT_COSTS["chat"]
DAILY_BONUS_CHAT = 0

INGEST_ACTIONS = frozenset({"ingest_text", "ingest_upload", "ingest_url"})
CHAT_ACTIONS = frozenset({"chat"})
VIDEO_PLATFORMS = frozenset({"bilibili", "youtube", "wechat_video"})


@dataclass
class QuotaStatus:
    user_key: str
    graphs_used: int
    graphs_limit: int
    graphs_remaining: int
    chat_by_graph: dict[str, dict]
    can_create_graph: bool
    daily_bonus_available: bool
    tier: str = "free"
    expires_at: str | None = None
    credit_balance: int = FREE_BASE_CREDITS
    credit_used: int = 0
    credit_granted: int = 0
    can_chat: bool = True

    def to_dict(self) -> dict:
        active_entitlement = self.tier in ("admin", "trial", "member")
        if active_entitlement:
            label = "超级账号" if self.tier == "admin" else "内测特权"
            suffix = "" if self.tier == "admin" or not self.expires_at else f" · 有效至 {self.expires_at[:10]}"
            return {
                "tier": self.tier,
                "expires_at": self.expires_at,
                "graphs": {"used": self.graphs_used, "limit": None, "remaining": None, "can_create": True},
                "chat": {},
                "daily_bonus_chat": 0,
                "credits": {
                    "balance": None,
                    "base": FREE_BASE_CREDITS,
                    "granted": self.credit_granted,
                    "used": self.credit_used,
                    "credit_rmb": CREDIT_RMB,
                    "display_graph_credits": DISPLAY_GRAPH_CREDITS,
                    "recharge_packs": RECHARGE_PACKS,
                },
                "entitlement": {"tier": self.tier, "active": True, "expires_at": self.expires_at},
                "copy": {
                    "ingest_label": "生成新图谱",
                    "ingest_hint": f"{label} · 不限生成次数{suffix}",
                    "chat_hint": f"{label} · 生长追问不限{suffix}",
                    "account_hint": f"{label} · 不限生成与追问{suffix}",
                },
            }
        chat_remaining = self.credit_balance // CREDIT_COSTS["chat"]
        approx_graphs = self.credit_balance // DISPLAY_GRAPH_CREDITS
        return {
            "tier": self.tier,
            "expires_at": self.expires_at,
            "graphs": {
                "used": self.graphs_used,
                "limit": self.graphs_limit,
                "remaining": self.graphs_remaining,
                "can_create": self.can_create_graph,
            },
            "chat": self.chat_by_graph,
            "daily_bonus_chat": DAILY_BONUS_CHAT if self.daily_bonus_available else 0,
            "credits": {
                "balance": self.credit_balance,
                "base": FREE_BASE_CREDITS,
                "granted": self.credit_granted,
                "used": self.credit_used,
                "credit_rmb": CREDIT_RMB,
                "display_graph_credits": DISPLAY_GRAPH_CREDITS,
                "chat_cost": CREDIT_COSTS["chat"],
                "approx_graphs": approx_graphs,
                "approx_chats": chat_remaining,
                "recharge_packs": RECHARGE_PACKS,
            },
            "entitlement": {"tier": self.tier, "active": False, "expires_at": self.expires_at},
            "copy": {
                "ingest_label": "生成新图谱",
                "ingest_hint": f"还可生成约 {approx_graphs} 张概念网",
                "chat_hint": f"这张网还可追问约 {chat_remaining} 次；浏览已有节点不限",
                "account_hint": f"还可生成约 {approx_graphs} 张 · 追问约 {chat_remaining} 次",
            },
        }


def user_key(user_id: str | None) -> str:
    return (user_id or "").strip() or "__local__"


def _db_path() -> Path:
    return Path(__file__).parent / "data" / "graphs.db"


def _parse_dt(value: str | None) -> datetime | None:
    if not value:
        return None
    try:
        return datetime.fromisoformat(str(value).replace("Z", "+00:00"))
    except Exception:
        return None


def _active_entitlement(conn: sqlite3.Connection, uid: str) -> tuple[str, str | None]:
    row = conn.execute("SELECT tier, expires_at FROM entitlements WHERE user_id=?", [uid]).fetchone()
    if not row:
        return "free", None
    tier = (row[0] or "free").strip() or "free"
    expires_at = row[1]
    if tier in ("trial", "member"):
        exp = _parse_dt(expires_at)
        if exp and exp > datetime.now(exp.tzinfo):
            return tier, expires_at
    return "free", expires_at


def _grant_total(conn: sqlite3.Connection, uid: str) -> int:
    row = conn.execute(
        "SELECT COALESCE(SUM(amount), 0) FROM quota_grants WHERE user_id=? AND kind='credit'",
        [uid],
    ).fetchone()
    return int(row[0] or 0)


def _meta(row_meta: str | None) -> dict:
    if not row_meta:
        return {}
    try:
        data = json.loads(row_meta)
        return data if isinstance(data, dict) else {}
    except Exception:
        return {}


def _duration_minutes(meta: dict) -> int:
    sec = meta.get("duration_sec") or meta.get("duration") or meta.get("audio_duration_sec")
    try:
        sec = float(sec or 0)
    except Exception:
        sec = 0
    if sec <= 0:
        segments = meta.get("segments") or []
        if isinstance(segments, list) and segments:
            starts = []
            for seg in segments[-8:]:
                try:
                    starts.append(float(seg.get("start_sec") or seg.get("start") or 0))
                except Exception:
                    pass
            if starts:
                sec = max(starts) + 60
    if sec <= 0:
        return DEFAULT_VIDEO_MINUTES
    return max(1, math.ceil(sec / 60))


def credit_cost_for_usage(action: str, meta: dict | None = None) -> int:
    meta = meta or {}
    if action == "chat":
        return CREDIT_COSTS["chat"]
    if action == "ingest_text":
        return CREDIT_COSTS["ingest_keyword"] if meta.get("keyword") else CREDIT_COSTS["ingest_text"]
    if action == "ingest_upload":
        return CREDIT_COSTS["ingest_upload"]
    if action == "ingest_url":
        platform = str(meta.get("platform") or "").strip()
        is_video = bool(meta.get("is_video")) or platform in VIDEO_PLATFORMS
        if is_video:
            return CREDIT_COSTS["ingest_video_base"] + _duration_minutes(meta) * CREDIT_COSTS["ingest_video_per_min"]
        return CREDIT_COSTS["ingest_url"]
    return 0


def _credit_used(conn: sqlite3.Connection, uid: str) -> int:
    rows = conn.execute(
        "SELECT action, meta_json FROM usage_logs WHERE user_id=?",
        [uid],
    ).fetchall()
    return sum(credit_cost_for_usage(action, _meta(meta_json)) for action, meta_json in rows)


def _count_graph_creates(conn: sqlite3.Connection, uid: str) -> int:
    row = conn.execute(
        f"SELECT COUNT(DISTINCT graph_id) FROM usage_logs WHERE user_id=? AND action IN ({','.join('?'*len(INGEST_ACTIONS))})",
        [uid, *INGEST_ACTIONS],
    ).fetchone()
    return int(row[0] or 0)


def _chat_counts(conn: sqlite3.Connection, uid: str) -> dict[str, int]:
    rows = conn.execute(
        f"SELECT graph_id, COUNT(*) FROM usage_logs WHERE user_id=? AND action IN ({','.join('?'*len(CHAT_ACTIONS))}) GROUP BY graph_id",
        [uid, *CHAT_ACTIONS],
    ).fetchall()
    return {gid: int(n) for gid, n in rows if gid}


def _daily_bonus_claimed(conn: sqlite3.Connection, uid: str) -> bool:
    return True


def _graph_create_order(conn: sqlite3.Connection, uid: str) -> list[str]:
    rows = conn.execute(
        f"""SELECT graph_id, MIN(created_at) FROM usage_logs
            WHERE user_id=? AND action IN ({','.join('?'*len(INGEST_ACTIONS))})
            GROUP BY graph_id ORDER BY MIN(created_at)""",
        [uid, *INGEST_ACTIONS],
    ).fetchall()
    return [r[0] for r in rows if r[0]]


def chat_limit_for_graph_index(index: int) -> int:
    """index: 0 = 第一张图谱"""
    if index <= 0:
        return FREE_CHAT_FIRST_GRAPH
    return FREE_CHAT_OTHER_GRAPHS


def get_quota_status(user_id: str | None = None) -> QuotaStatus:
    uid = user_key(user_id)
    if is_admin_user(user_id):
        return QuotaStatus(
            user_key=uid,
            graphs_used=0,
            graphs_limit=FREE_GRAPH_CREATES,
            graphs_remaining=FREE_GRAPH_CREATES,
            chat_by_graph={},
            can_create_graph=True,
            daily_bonus_available=False,
            tier="admin",
        )
    db = _db_path()
    if not db.exists():
        return QuotaStatus(
            user_key=uid,
            graphs_used=0,
            graphs_limit=FREE_GRAPH_CREATES,
            graphs_remaining=FREE_GRAPH_CREATES,
            chat_by_graph={},
            can_create_graph=True,
            daily_bonus_available=True,
        )
    with sqlite3.connect(db) as conn:
        tier, expires_at = _active_entitlement(conn, uid)
        granted = _grant_total(conn, uid)
        used_credits = _credit_used(conn, uid)
        graphs_used = _count_graph_creates(conn, uid)
        order = _graph_create_order(conn, uid)
        chat_counts = _chat_counts(conn, uid)
        bonus_claimed = _daily_bonus_claimed(conn, uid)
    balance = max(0, FREE_BASE_CREDITS + granted - used_credits)

    chat_by_graph: dict[str, dict] = {}
    for i, gid in enumerate(order):
        used = chat_counts.get(gid, 0)
        limit = balance // CREDIT_COSTS["chat"]
        extra = 0
        effective_limit = used + limit
        chat_by_graph[gid] = {
            "used": used,
            "limit": limit,
            "bonus": extra,
            "remaining": limit,
            "can_chat": tier in ("trial", "member") or balance >= CREDIT_COSTS["chat"],
            "is_first_graph": i == 0,
        }

    remaining = balance // DISPLAY_GRAPH_CREDITS
    can_create = tier in ("trial", "member") or balance >= min(CREDIT_COSTS["ingest_keyword"], CREDIT_COSTS["ingest_text"])
    return QuotaStatus(
        user_key=uid,
        graphs_used=graphs_used,
        graphs_limit=FREE_BASE_CREDITS // DISPLAY_GRAPH_CREDITS,
        graphs_remaining=remaining,
        chat_by_graph=chat_by_graph,
        can_create_graph=can_create,
        daily_bonus_available=not bonus_claimed,
        tier=tier,
        expires_at=expires_at,
        credit_balance=balance,
        credit_used=used_credits,
        credit_granted=granted,
        can_chat=tier in ("trial", "member") or balance >= CREDIT_COSTS["chat"],
    )


def check_graph_create(
    user_id: str | None,
    action: str = "ingest_text",
    meta: dict | None = None,
) -> tuple[bool, str, QuotaStatus]:
    if is_admin_user(user_id):
        return True, "", get_quota_status(user_id)
    st = get_quota_status(user_id)
    if st.tier in ("trial", "member"):
        return True, "", st
    cost = max(1, credit_cost_for_usage(action, meta))
    if st.credit_balance >= cost:
        return True, "", st
    return False, (
        "当前生成额度不足。已有图谱仍可浏览、回看；"
        "想继续生成，在内测群里说一声即可加额度。"
    ), st


def check_chat(user_id: str | None, graph_id: str) -> tuple[bool, str, QuotaStatus]:
    if is_admin_user(user_id):
        return True, "", get_quota_status(user_id)
    st = get_quota_status(user_id)
    if st.tier in ("trial", "member") or st.credit_balance >= CREDIT_COSTS["chat"]:
        return True, "", st
    return False, (
        "这张网的生长追问额度暂时用完。已有结构随便逛；"
        "想继续追问长节点，在内测群里说一声即可加额度。"
    ), st
